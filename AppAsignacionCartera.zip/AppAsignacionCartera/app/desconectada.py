import pandas as pd
from app.reporte import Reporte

class Desconectada(Reporte):
    def __init__(self, df):
        super().__init__(df)

    def informe(self):
        result = self.df[self.filtrar_exc_prepago & ~self.vias_pago & self.filtrar_desc & self.filtrar_altas & self.filtrar_res_com_1 & self.filtrar_deuda_total]

        return result