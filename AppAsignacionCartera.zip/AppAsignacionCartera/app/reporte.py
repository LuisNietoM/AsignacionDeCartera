import pandas as pd

class Reporte:
    def __init__(self, df):
        self.df = df
        self.get_antiguedad() 
        self.get_deuda_vencida()

        # Filtros 
        self.filtrar_bajas = (self.df['Estado de la cuenta'] == 'BAJA')
        self.filtrar_altas = (self.df['Estado de la cuenta'] == 'ALTA')
        self.filtrar_desc = (self.df['Estado de la instalación'] == 'DESCONECTADO')
        self.filtrar_conec = (self.df['Estado de la instalación'] == 'CONECTADO')
        self.filtrar_exc_gobierno_1 = (self.df['Categoría cuenta contrato'] != 'Gobierno')
        self.filtrar_exc_gobierno_2 = (self.df['Característica determinación de cuenta'] != 'Gobierno')
        self.filtrar_exc_prepago = (self.df['Característica determinación de cuenta'] != 'Prepago')
        self.filtrar_deuda_vencida = (self.df['Deuda 60 o más'] > 0)
        self.filtrar_deuda_total = (self.df['Deuda total'] > 0)
        self.filtrar_no_acuerdo = (self.df['Plan de Pago'] != 'X')
        self.vias_pago =  (self.df['Vía de Pago'].isin(['T', 'E', 'A']))
        self.filtra_deuda_30_o_mas_dias = (self.df['Antiguedad'].isin(['J. Más 365 días', 'I. 365 días', 'H. 210 días', 'G. 180 días', 'F. 150 días', 'E. 120 días', 'D. 90 días', 'C. 60 días', 'B. 30 días']))
        self.filtrar_res_com_1 = (self.df['Categoría cuenta contrato'].isin(['Residencial', 'Comercial']))            
        self.filtrar_res_com_2 = (self.df['Característica determinación de cuenta'].isin(['Residenciales/ Empleados ENSA', 'Empleados Otras Empresas', 'Comercial']))


    def get_antiguedad(self):
        self.df['Antiguedad'] = self.df.apply(self.antiguedad, axis=1)
    
    def get_deuda_vencida(self):
        self.df['Deuda 60 o más'] = self.df[['Deuda 60 días', 'Deuda 90 días', 'Deuda 120 días', 'Deuda 150 días', 'Deuda 180 días', 'Deuda 210 días','Deuda 365 días', 'Deuda > 365 días']].sum(axis=1)

    def antiguedad(self, row):
        deuda_columns = [
            'Deuda corriente', 'Deuda 30 días', 'Deuda 60 días', 'Deuda 90 días',
            'Deuda 120 días', 'Deuda 150 días', 'Deuda 180 días', 'Deuda 210 días',
            'Deuda 365 días', 'Deuda > 365 días'
        ]
        
        deudas = [row[col] for col in deuda_columns]

        antiguedad_categorias = {
            'J. Más 365 días': any(deuda > 0 for deuda in deudas[9:]),
            'I. 365 días': deudas[8] > 0,
            'H. 210 días': deudas[7] > 0,
            'G. 180 días': deudas[6] > 0,
            'F. 150 días': deudas[5] > 0,
            'E. 120 días': deudas[4] > 0,
            'D. 90 días': deudas[3] > 0,
            'C. 60 días': deudas[2] > 0,
            'B. 30 días': deudas[1] > 0,
            'A. Corriente': deudas[0] > 0,
            'X. Saldo 0': all(deuda == 0 for deuda in deudas)
        }

        for categoria, condicion in antiguedad_categorias.items():
            if condicion:
                return categoria

        return 'Categoría no definida'
    

