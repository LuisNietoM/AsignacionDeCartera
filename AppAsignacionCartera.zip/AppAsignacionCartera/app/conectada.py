import pandas as pd
from app.reporte import Reporte

class Conectada(Reporte):
    def __init__(self, df):
        super().__init__(df)


    def informe(self):

        result = self.df[self.filtrar_res_com_2 & self.filtrar_conec & self.filtrar_altas & self.filtra_deuda_30_o_mas_dias & self.filtrar_exc_gobierno_1 & self.filtrar_no_acuerdo & ~self.vias_pago]

        return result