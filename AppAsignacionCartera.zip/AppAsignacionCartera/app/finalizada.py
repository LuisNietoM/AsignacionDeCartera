import pandas as pd
from app.reporte import Reporte

class Finalizada(Reporte):
    def __init__(self, df):
        super().__init__(df)

    def informe(self):
        # Filtro las que se dieron de baja en el mes anterior.
        fecha_actual = pd.to_datetime('today').normalize()
        self.df['Fecha de baja'] = pd.to_datetime(self.df['Fecha de baja'], format='%Y.%m.%d', errors='coerce')

        mes = fecha_actual.month
        anio = fecha_actual.year

        if mes > 1:
            filtro_anio = (self.df['Fecha de baja'].dt.year == anio)
            filtro_mes = (self.df['Fecha de baja'].dt.month == (mes - 1))
        else:
            filtro_anio = (self.df['Fecha de baja'].dt.year == (anio - 1))
            filtro_mes = (self.df['Fecha de baja'].dt.month == 12)

        # Filtro monto > 10 y menores a 10k.
        filtro_monto_1 = self.df['Deuda total'] > 10
        # filtro_monto_2 = self.df['Deuda total'] < 10_000 

        # Resultados
        result = self.df[
            filtro_anio & filtro_mes & filtro_monto_1 & self.filtrar_bajas & self.filtrar_exc_gobierno_1 & self.filtrar_exc_gobierno_2 & self.filtrar_exc_prepago]

        # Exportar
        return result