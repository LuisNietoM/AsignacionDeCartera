import pandas as pd
from tkinter import *
from tkinter import ttk
from tkinter import filedialog
from tkinter import messagebox
from app.conectada import Conectada
from app.finalizada import Finalizada
from app.desconectada import Desconectada

COLORS = {'primary': '#00643b', 'secondary': '#71ab19', 'tertiary': '#dadf53'}

class App:

    def __init__(self, root):
        # Dataframe 
        self.df = pd.DataFrame()

        # Root
        self.root = root
        self.root.title('ASIGNACIÓN DE CARTERA')
        self.root.geometry("950x500")
        self.root.resizable(False, False)

        # Container files
        self.container_ficheros = ttk.Frame(self.root)
        self.container_ficheros.pack(expand=True, fill=BOTH) 

        # Headers
        ttk.Label(self.container_ficheros, text='Search', foreground=COLORS['primary'], font=('Arial', 12, 'bold')).grid(row=0, column=0)
        ttk.Label(self.container_ficheros, text='File name', foreground=COLORS['primary'], font=('Arial', 12, 'bold')).grid(row=0, column=1)
        ttk.Label(self.container_ficheros, text='Primary Key', foreground=COLORS['primary'], font=('Arial', 12, 'bold')).grid(row=0, column=2)

        # Auxiliar
        self.btn_aux = ttk.Button(self.container_ficheros, text='Auxiliar de morosidad', command=self.select_aux, width=20)
        self.btn_aux.grid(row=1, column=0, pady=5)
        self.label_aux = ttk.Label(self.container_ficheros, text='Ningún archivo seleccionado')
        self.label_aux.grid(row=1, column=1)
        self.txt_aux = ttk.Entry(self.container_ficheros)
        self.txt_aux.insert(END, 'Número cuenta contrato')
        self.txt_aux.grid(row=1, column=2)

        # Cortados
        self.btn_cortados = ttk.Button(self.container_ficheros, text='Informe Cortados', command=self.select_cortados, width=20)
        self.btn_cortados.grid(row=2, column=0, pady=5)
        self.label_cortados = ttk.Label(self.container_ficheros, text='Ningún archivo seleccionado')
        self.label_cortados.grid(row=2, column=1)
        self.txt_cortados = ttk.Entry(self.container_ficheros)
        self.txt_cortados.insert(END, 'Cuenta Contrato')
        self.txt_cortados.grid(row=2, column=2)

        # APC
        self.btn_apc = ttk.Button(self.container_ficheros, text='Informe APC', command=self.select_apc, width=20)
        self.btn_apc.grid(row=3, column=0, pady=5)
        self.label_apc = ttk.Label(self.container_ficheros, text='Ningún archivo seleccionado')
        self.label_apc.grid(row=3, column=1)
        self.txt_apc = ttk.Entry(self.container_ficheros)
        self.txt_apc.insert(END, 'Cuenta')
        self.txt_apc.grid(row=3, column=2)

        # CNR
        self.btn_cnr = ttk.Button(self.container_ficheros, text='Informe CNR', command=self.select_cnr, width=20)
        self.btn_cnr.grid(row=4, column=0, pady=5)
        self.label_cnr = ttk.Label(self.container_ficheros, text='Ningún archivo seleccionado')
        self.label_cnr.grid(row=4, column=1)
        self.txt_cnr = ttk.Entry(self.container_ficheros)
        self.txt_cnr.insert(END, 'NAC')
        self.txt_cnr.grid(row=4, column=2)

        # Cero
        self.btn_cero = ttk.Button(self.container_ficheros, text='Informe Cero', command=self.select_cero, width=20)
        self.btn_cero.grid(row=5, column=0, pady=5)
        self.label_cero = ttk.Label(self.container_ficheros, text='Ningún archivo seleccionado')
        self.label_cero.grid(row=5, column=1)
        self.txt_cero = ttk.Entry(self.container_ficheros)
        self.txt_cero.insert(END, 'NAC')
        self.txt_cero.grid(row=5, column=2)

        # Nulos
        self.btn_nulo = ttk.Button(self.container_ficheros, text='Informe Nulo', command=self.select_nulo, width=20)
        self.btn_nulo.grid(row=6, column=0, pady=5)
        self.label_nulo = ttk.Label(self.container_ficheros, text='Ningún archivo seleccionado')
        self.label_nulo.grid(row=6, column=1)
        self.txt_nulo = ttk.Entry(self.container_ficheros)
        self.txt_nulo.insert(END, 'NAC')
        self.txt_nulo.grid(row=6, column=2)

        # Covid
        self.btn_covid = ttk.Button(self.container_ficheros, text='Informe Covid', command=self.select_covid, width=20)
        self.btn_covid.grid(row=7, column=0, pady=5)
        self.label_covid = ttk.Label(self.container_ficheros, text='Ningún archivo seleccionado')
        self.label_covid.grid(row=7, column=1)
        self.txt_covid = ttk.Entry(self.container_ficheros)
        self.txt_covid.insert(END, 'Número de cuenta contrato')
        self.txt_covid.grid(row=7, column=2)

        # Consumo medio
        self.btn_consumo = ttk.Button(self.container_ficheros, text='Rango de consumo', command=self.select_consumo, width=20)
        self.btn_consumo.grid(row=8, column=0, pady=5)
        self.label_consumo = ttk.Label(self.container_ficheros, text='Ningún archivo seleccionado')
        self.label_consumo.grid(row=8, column=1)
        self.txt_consumo = ttk.Entry(self.container_ficheros)
        self.txt_consumo.insert(END, 'NAC')
        self.txt_consumo.grid(row=8, column=2)

        # Reclamos
        self.btn_reclamos = ttk.Button(self.container_ficheros, text='Reclamos', command=self.select_reclamos, width=20)
        self.btn_reclamos.grid(row=9, column=0, pady=5)
        self.label_reclamos = ttk.Label(self.container_ficheros, text='Ningún archivo seleccionado')
        self.label_reclamos.grid(row=9, column=1)
        self.txt_reclamos = ttk.Entry(self.container_ficheros)
        self.txt_reclamos.insert(END, 'Cuenta Contrato - Clave')
        self.txt_reclamos.grid(row=9, column=2)

        # Remotos
        self.btn_remotos = ttk.Button(self.container_ficheros, text='Remotos', command=self.select_remotos, width=20)
        self.btn_remotos.grid(row=10, column=0, pady=5)
        self.label_remotos = ttk.Label(self.container_ficheros, text='Ningún archivo seleccionado')
        self.label_remotos.grid(row=10, column=1)
        self.txt_remotos = ttk.Entry(self.container_ficheros)
        self.txt_remotos.insert(END, 'NAC')
        self.txt_remotos.grid(row=10, column=2)

        # Container Button
        self.container_btn = ttk.Frame(self.root)
        self.container_btn.pack(padx=10, pady=5)

        self.btn = ttk.Button(self.container_btn, command=self.read_files, text='Run', style='Primary.TButton')
        self.btn.pack(side=LEFT)
        self.btn1 = ttk.Button(self.container_btn, command=self.get_conectada, text='Conectada', state='disabled', style='Secondary.TButton')
        self.btn1.pack(side=LEFT)
        self.btn2 = ttk.Button(self.container_btn, command=self.get_desconectada, text='Desconectada', state='disabled', style='Secondary.TButton')
        self.btn2.pack(side=LEFT)
        self.btn3 = ttk.Button(self.container_btn, command=self.get_finalizada, text='Finalizada', state='disabled', style='Secondary.TButton')
        self.btn3.pack(side=LEFT)

        # Create custom styles for buttons
        self.style = ttk.Style()
        self.style.theme_use('default')
        self.style.configure('Primary.TButton', foreground='white', background=COLORS['primary'], font=('Arial', 10, 'bold'), padding=5)
        self.style.map('Primary.TButton', background=[('active', COLORS['secondary'])])
        self.style.configure('Secondary.TButton', foreground='white', background=COLORS['secondary'], font=('Arial', 10, 'bold'), padding=5)
        self.style.map('Secondary.TButton', background=[('active', COLORS['tertiary'])])

        # Configure weight for rows and columns
        self.container_ficheros.grid_columnconfigure(0, weight=1)
        self.container_ficheros.grid_columnconfigure(1, weight=1)
        self.container_ficheros.grid_columnconfigure(2, weight=1)


    def select_aux(self):
        ruta = filedialog.askopenfilename(title='Seleccionar archivo', filetypes=[('Archivos de texto', '*.txt')])
        if ruta:
            self.label_aux.config(text=ruta)
        else:
            self.label_aux.config(text='Ningún archivo seleccionado')

    def select_cortados(self):
        ruta = filedialog.askopenfilename(title='Seleccionar archivo', filetypes=[('Archivos de Excel', '*.xlsx')])
        if ruta:
            self.label_cortados.config(text=ruta)
        else:
            self.label_cortados.config(text='Ningún archivo seleccionado')

    def select_apc(self):
        ruta = filedialog.askopenfilename(title='Seleccionar archivo', filetypes=[('Archivos de Excel', '*.xlsx')])
        if ruta:
            self.label_apc.config(text=ruta)
        else:
            self.label_apc.config(text='Ningún archivo seleccionado')

    def select_cnr(self):
        ruta = filedialog.askopenfilename(title='Seleccionar archivo', filetypes=[('Archivos de Excel', '*.xlsx')])
        if ruta:
            self.label_cnr.config(text=ruta)
        else:
            self.label_cnr.config(text='Ningún archivo seleccionado')

    def select_cero(self):
        ruta = filedialog.askopenfilename(title='Seleccionar archivo', filetypes=[('Archivos de Excel', '*.xlsx')])
        if ruta:
            self.label_cero.config(text=ruta)
        else:
            self.label_cero.config(text='Ningún archivo seleccionado')

    def select_nulo(self):
        ruta = filedialog.askopenfilename(title='Seleccionar archivo', filetypes=[('Archivos de Excel', '*.xlsx')])
        if ruta:
            self.label_nulo.config(text=ruta)
        else:
            self.label_nulo.config(text='Ningún archivo seleccionado')

    def select_covid(self):
        ruta = filedialog.askopenfilename(title='Seleccionar archivo', filetypes=[('Archivos de Excel', '*.xlsx')])
        if ruta:
            self.label_covid.config(text=ruta)
        else:
            self.label_covid.config(text='Ningún archivo seleccionado')
    
    def select_consumo(self):
        ruta = filedialog.askopenfilename(title='Seleccionar archivo', filetypes=[('Archivos de Excel', '*.xlsx')])
        if ruta:
            self.label_consumo.config(text=ruta)
        else:
            self.label_consumo.config(text='Ningún archivo seleccionado')

    def select_reclamos(self):
        ruta = filedialog.askopenfilename(title='Seleccionar archivo', filetypes=[('Archivos de Excel', '*.xlsx')])
        if ruta:
            self.label_reclamos.config(text=ruta)
        else:
            self.label_reclamos.config(text='Ningún archivo seleccionado')
    
    def select_remotos(self):
        ruta = filedialog.askopenfilename(title='Seleccionar archivo', filetypes=[('Archivos de Excel', '*.xlsx')])
        if ruta:
            self.label_remotos.config(text=ruta)
        else:
            self.label_remotos.config(text='Ningún archivo seleccionado')

    def read_files(self):
        if self.label_aux.cget('text') == 'Ningún archivo seleccionado':
            messagebox.showinfo('Auxiliar de morosidad', 'El Auxiliar de morosidad es obligatorio.')
        else:
            self.df = pd.read_csv(self.label_aux.cget('text'),  sep='\t', encoding='iso-8859-1', low_memory=False, index_col=self.txt_aux.get())

            try:
                if self.label_cortados.cget('text') != 'Ningún archivo seleccionado':
                    cort = pd.read_excel(self.label_cortados.cget('text'), index_col=self.txt_cortados.get())
                    cort = cort.iloc[:, [5, 9, 11, 19]]
                    self.df = self.df.join(cort, how='left')

                if self.label_apc.cget('text') != 'Ningún archivo seleccionado':
                    apc = pd.read_excel(self.label_apc.cget('text'), index_col=self.txt_apc.get())
                    apc_index = apc.index.values
                    self.df.loc[self.df.index.isin(apc_index), 'APC'] = True
                    self.df.loc[~self.df.index.isin(apc_index), 'APC'] = False

                if self.label_cnr.cget('text') != 'Ningún archivo seleccionado':
                    cnr = pd.read_excel(self.label_cnr.cget('text'), index_col=self.txt_cnr.get())
                    cnr_index = cnr.index.values
                    self.df.loc[self.df.index.isin(cnr_index), 'CNR'] = True
                    self.df.loc[~self.df.index.isin(cnr_index), 'CNR'] = False            

                if self.label_cero.cget('text') != 'Ningún archivo seleccionado':
                    cero = pd.read_excel(self.label_cero.cget('text'), index_col=self.txt_cero.get())
                    cero_index = cero.index.values
                    self.df.loc[self.df.index.isin(cero_index), 'NULO/CERO'] = "CERO"
                    
                if self.label_nulo.cget('text') != 'Ningún archivo seleccionado':
                    nulo = pd.read_excel(self.label_nulo.cget('text'), index_col=self.txt_nulo.get())
                    nulo_index = nulo.index.values
                    self.df.loc[self.df.index.isin(nulo_index), 'NULO/CERO'] = "NULO"

                if self.label_covid.cget('text') != 'Ningún archivo seleccionado':
                    covid = pd.read_excel(self.label_covid.cget('text'), index_col=self.txt_covid.get())
                    covid_index = covid.index.values
                    self.df.loc[self.df.index.isin(covid_index), 'COVID'] = True
                    self.df.loc[~self.df.index.isin(covid_index), 'COVID'] = False

                if self.label_consumo.cget('text') != 'Ningún archivo seleccionado':
                    df_consumo_medio = pd.read_excel(self.label_consumo.cget('text'), index_col=self.txt_consumo.get())
                    consumo_medio = df_consumo_medio.loc[:, 'Consumo Promedio']
                    self.df = self.df.join(consumo_medio, how='left')

                if self.label_reclamos.cget('text') != 'Ningún archivo seleccionado':
                    reclamos = pd.read_excel(self.label_reclamos.cget('text'), index_col=self.txt_reclamos.get())
                    reclamos.rename(columns={'Status de usuario - Texto explicativo':'RECLAMO'}, inplace=True)
                    self.df = self.df.join(reclamos, how='left')

                if self.label_remotos.cget('text') != 'Ningún archivo seleccionado':
                    remotos = pd.read_excel(self.label_remotos.cget('text'), index_col=self.txt_remotos.get())
                    remotos_index = remotos.index.values
                    self.df.loc[self.df.index.isin(remotos_index), 'REMOTOS'] = True
                    self.df.loc[~self.df.index.isin(remotos_index), 'REMOTOS'] = False                    

                messagebox.showinfo('Proceso completado', 'Proceso de unión de datos terminado.')
                self.btn1.config(state='normal')
                self.btn2.config(state='normal')
                self.btn3.config(state='normal')

            except Exception as e:
                messagebox.showerror('Error de Join', f'Hubo un problema al combinar los DataFrames: {e}')

    def get_conectada(self):
        info = Conectada(self.df).informe()
        info.to_csv('./Conectada.csv', sep=';', encoding='iso-8859-1') 
        messagebox.showinfo('Download', 'La asignación fue descargada satisfactoriamente')

    def get_desconectada(self):
        info = Desconectada(self.df).informe()
        info.to_csv('./Desconectada.csv', sep=';', encoding='iso-8859-1') 
        messagebox.showinfo('Download', 'La asignación fue descargada satisfactoriamente') 

    def get_finalizada(self):
        info = Finalizada(self.df).informe()
        info.to_csv('./Finalizada.csv', sep=';', encoding='iso-8859-1') 
        messagebox.showinfo('Download', 'La asignación fue descargada satisfactoriamente')

